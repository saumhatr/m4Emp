package com.cg.appl.controllers;

import java.util.List;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.services.EmpServices;

//http://localhost:8085/Spring120MvcLogin/login.do
@Controller
public class EmpCrudController {
	private EmpServices service;

	@Resource(name = "EmpService")
	public void setEmpServices(EmpServices service) {
		this.service = service;
	}

	@RequestMapping("/welcome.do")
	public ModelAndView getWelcomePage() {
		ModelAndView model = new ModelAndView("welcome");
		return model;
	}

	@RequestMapping("/enterEmployeeNumber.do")
	public ModelAndView enterEmpNumber() {
		System.out.println("in controlling method");
		ModelAndView model = new ModelAndView("enterEmployeeNumber");
		return model;
	}

	@RequestMapping("/getEmployeeDetails.do")
	public ModelAndView getEmpDetails(@RequestParam int empId) {
		System.out.println("in controlling method" + empId);

		ModelAndView model = null;
		try {
			Emp emp = service.getEmpDetails(empId);
			model = new ModelAndView("EmpDetails");
			model.addObject("EmpDetails", emp);
		} catch (EmpException e) {
			model = new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		}
		return model;
	}

	@RequestMapping("/listAllEmployees.do")
	public ModelAndView ListAllEmps() {
		ModelAndView model = null;
		try {
			
			List<Emp> empList = service.getAllEmployees();
			model = new ModelAndView("listAllEmployees");
			model.addObject("empList", empList);
		} catch (EmpException e) {
			model.addObject("errMsg", e.getMessage());
		}
		return model;
	}

	@RequestMapping("/entryForm.do")
	public ModelAndView getEntryForm() {
		ModelAndView model = new ModelAndView("entryForm");
		model.addObject("emp", new Emp());
		return model;
	}

	@RequestMapping("/submitEntryForm.do")
	public ModelAndView submitEntryForm(@ModelAttribute @Valid Emp emp,
			BindingResult result) {
		ModelAndView model = new ModelAndView();

		if (result.hasErrors()) {
			model.setViewName("entryForm");
			return model;
		}
		try {
			Emp EmpResponse = service.insertNewEmployee(emp);
			model.setViewName("successInsert");
			model.addObject("empo", EmpResponse);
		} catch (EmpException e) {
			model.setViewName("error");
			model.addObject("errMsg",
					"Record insertion failed" + " " + e.getMessage());
		}
		return model;
	}
	
	@RequestMapping("/getUpdateForm.do")
	public ModelAndView getupdateForm(@RequestParam("id") int empId) {
		ModelAndView model = null;
		try {
			Emp emp = service.getEmpDetails(empId);
			model = new ModelAndView("updateForm");
			model.addObject("emp", emp);
		} catch (EmpException e) {
			model.setViewName("error");
			model.addObject("errMsg", "Record insertion failed" + " " + e.getMessage());
		}
		
		return model;
	}
	
	@RequestMapping("/submitUpdateForm.do")
	public String submitUpdateForm(@ModelAttribute @Valid Emp emp,BindingResult result, Model model) {

		/*if (result.hasErrors()) {
			model.setViewName("entryForm");
			return model;
		}*/
		
		try {
			Emp EmpResponse = service.updateEmp(emp);
			model.addAttribute("empo", EmpResponse);
			return "successUpdate";
		} catch (EmpException e) {
			model.addAttribute("errMsg", "Record insertion failed" + " " + e.getMessage());
			return "error";
		}
	}
	
	
	@RequestMapping("/deleteEmp.do")
	public ModelAndView deleteEmp(@RequestParam("id") int empId) {
		ModelAndView model = null;
		
		try {
			int c = service.deleteEmp(empId);
			if(c > 0){
				model = new ModelAndView("successDelete");
			}
		} catch (EmpException e) {
			model.setViewName("error");
			model.addObject("errMsg", "Record insertion failed" + " " + e.getMessage());
		}
		
		return model;
	}
	

}
