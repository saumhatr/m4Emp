package com.cg.appl.daos;

import java.util.List;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;

public interface EmpDao {
	Emp getEmpDetails(int EmpId) throws EmpException;
	List<Emp> getAllEmployees() throws EmpException;
	Emp insertNewEmployee(Emp emp) throws EmpException;
	public Emp updateEmp(Emp emp) throws EmpException;
	public int deleteEmp(int empId) throws EmpException;
}
