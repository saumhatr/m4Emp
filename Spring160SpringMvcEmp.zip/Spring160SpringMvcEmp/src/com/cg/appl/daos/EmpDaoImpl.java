package com.cg.appl.daos;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.RollbackException;

import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;

@Repository("EmpDao")
public class EmpDaoImpl implements EmpDao {
	private EntityManagerFactory factory;
	
	@PersistenceContext
	private EntityManager manager;

	/*@Resource(name = "entityMFactory")
	public void setEntityMFactory(EntityManagerFactory factory) {
		this.factory = factory;
	}*/

	@Override
	public Emp getEmpDetails(int EmpId) throws EmpException {
		//EntityManager manager = factory.createEntityManager();
		Emp Emp = manager.find(Emp.class, EmpId);
		return Emp;
	}

	@Override
	public List<Emp> getAllEmployees() throws EmpException {
		//EntityManager manager = factory.createEntityManager();
		String queryStr = "select t from emp121 t";
		Query query = manager.createQuery(queryStr, Emp.class);
		return query.getResultList();
	}

	@Override
	public Emp insertNewEmployee(Emp emp) throws EmpException {
		//EntityManager manager = factory.createEntityManager();
		try {
			//EntityTransaction trans = manager.getTransaction();
			//trans.begin();
			manager.persist(emp);
			//trans.commit();
		} catch (RollbackException e) {
			throw new EmpException("Record not inserted. ", e);
		}
		return emp;
	}

	@Override
	public Emp updateEmp(Emp emp) throws EmpException {
		//EntityManager manager = factory.createEntityManager();
		//manager.getTransaction().begin();
		manager.merge(emp);
		//manager.getTransaction().commit();
		return emp;
	}

	@Override
	public int deleteEmp(int empId) throws EmpException {
		//EntityManager manager = factory.createEntityManager();
		Emp emp= manager.find(Emp.class, empId);
		//manager.getTransaction().begin();
		manager.remove(emp);
		//manager.getTransaction().commit();
		return empId;
	}
	
	

}
