package com.cg.appl.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity(name = "emp121")
@Table(name = "emp12")
@SequenceGenerator(name = "trainee_generate", sequenceName = "TRAINEE_SEQ", allocationSize = 1, initialValue = 1002)
public class Emp {
	private int empId;
	private String empName;
	private String empSal;
	private String empAge;

	public Emp() {
		// TODO Auto-generated constructor stub
	}

	@Id
	@Column(name="empId")
	@GeneratedValue(generator = "trainee_generate", strategy = GenerationType.SEQUENCE)
	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}
	
	@NotEmpty(message="Name should not be empty")
	@Size(min=3, max=10, message="Name must be of size between 3 and 10.")
	@Column(name="empName")
	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	@Column(name="empSal")
	public String getEmpSal() {
		return empSal;
	}

	public void setEmpSal(String empSal) {
		this.empSal = empSal;
	}

	@Column(name="empAge")
	public String getEmpAge() {
		return empAge;
	}

	public void setEmpAge(String empAge) {
		this.empAge = empAge;
	}

	@Override
	public String toString() {
		return "emp [empId=" + empId + ", empName=" + empName + ", empSal="
				+ empSal + ", empAge=" + empAge + "]";
	}
	
}
