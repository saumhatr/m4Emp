package com.cg.appl.services;

import java.util.List;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;

public interface EmpServices {
	Emp getEmpDetails(int EmpId) throws EmpException;
	List<Emp> getAllEmployees() throws EmpException;
	Emp insertNewEmployee(Emp emp) throws EmpException;
	public Emp updateEmp(Emp emp) throws EmpException;
	public int deleteEmp(int empId) throws EmpException;
}
