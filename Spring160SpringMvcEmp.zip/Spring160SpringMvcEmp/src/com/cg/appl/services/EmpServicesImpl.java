package com.cg.appl.services;

import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.appl.daos.EmpDao;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;

@Service("EmpService")
@Transactional
public class EmpServicesImpl implements EmpServices {
	private EmpDao dao;

	@Resource(name = "EmpDao")
	public void setEmpDao(EmpDao dao) {
		this.dao = dao;
	}

	@Override
	public Emp getEmpDetails(int EmpId) throws EmpException {
		return dao.getEmpDetails(EmpId);
	}

	@Override
	public List<Emp> getAllEmployees() throws EmpException {
		return dao.getAllEmployees();
	}

	@Transactional
	@Override
	public Emp insertNewEmployee(Emp emp) throws EmpException {
		return dao.insertNewEmployee(emp);
	}

	@Override
	public Emp updateEmp(Emp emp) throws EmpException {
		// TODO Auto-generated method stub
		return dao.updateEmp(emp);
	}


	@Override
	public int deleteEmp(int empId) throws EmpException {
		// TODO Auto-generated method stub
		return dao.deleteEmp(empId);
	}

}
